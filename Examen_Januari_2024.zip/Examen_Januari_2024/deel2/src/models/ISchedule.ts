export interface ISchedule {
    cinemaId: string
    cinemaLocation: string
    time: string
    id: string
}

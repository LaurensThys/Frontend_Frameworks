export interface IUser {
    email: string
    id: string
}

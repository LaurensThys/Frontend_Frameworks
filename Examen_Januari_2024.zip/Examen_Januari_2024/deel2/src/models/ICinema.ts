export interface ICinema {
    id: string
    location: string
}

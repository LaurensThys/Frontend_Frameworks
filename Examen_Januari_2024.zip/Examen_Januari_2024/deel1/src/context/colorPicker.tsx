import {createContext} from 'react'

interface ColorPickerProps {

}

const ColorPicker: createContext<ColorPickerProps>({

},
})


export default ColorPicker